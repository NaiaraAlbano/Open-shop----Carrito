package tiendaabierta;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Naiara
 */
public class Carrito {

    static ArrayList<ItemCarrito> productosEnCarrito = new ArrayList<ItemCarrito>();

    int idCarrito;
    Date fechaCreacion;
    Date fechaModificacion;

    public Carrito(int idCarrito, Date fechaCreacion, Date fechaModificacion) {
        this.idCarrito = idCarrito;
        this.fechaCreacion = fechaCreacion;
        this.fechaModificacion = fechaModificacion;
    }

    public int getIdCarrito() {
        return idCarrito;
    }

    public void setIdCarrito(int idCarrito) {
        this.idCarrito = idCarrito;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Date getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(Date fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }

    public static void Agregar(Producto producto, int cantidad) {

        if (!(ProductoYaFueAgregado(producto))) {
            ItemCarrito itemCarrito = new ItemCarrito();
            itemCarrito.Producto = producto;
            itemCarrito.Cantidad = cantidad;
            productosEnCarrito.add(itemCarrito);
        } else {
            for (ItemCarrito item : productosEnCarrito) {
                if (item.Producto == producto) {
                    item.AumentarCantidad(cantidad);
                }
            }
        }
    }

    public static boolean ProductoYaFueAgregado(Producto producto) {
        boolean resultado = false;
        for (ItemCarrito itemCarrito : productosEnCarrito) {
            if (itemCarrito.Producto == producto) {
                resultado = true;
            }
        }

        return resultado;
    }

    public static void MostrarCarrito() {
        System.out.println("Productos en el carrito: \n");
        for (ItemCarrito carrito : productosEnCarrito) {
            System.out.println("Producto: " + carrito.Producto.getNombre() + carrito.Producto.getMarca() + "\nCantidad: " + carrito.Cantidad);
        }
    }

    public static void borrarElementoCarrito(int idProducto) {
        ItemCarrito itemAEliminar = null;
        for (ItemCarrito itemCarrito : productosEnCarrito) {
            if (idProducto == itemCarrito.Producto.getIdProducto()) {
                itemAEliminar = itemCarrito;
            }
        }

        productosEnCarrito.remove(itemAEliminar);
    }

    public static double MontoDeLaCompra() {
        double montoTotal = 0;
        for (ItemCarrito itemCarrito : productosEnCarrito) {
            montoTotal = montoTotal + (itemCarrito.Producto.getPrecio() * itemCarrito.Cantidad);
        }

        return montoTotal;
    }

    public void VaciarCarrito() {
        productosEnCarrito.clear();
    }
}
