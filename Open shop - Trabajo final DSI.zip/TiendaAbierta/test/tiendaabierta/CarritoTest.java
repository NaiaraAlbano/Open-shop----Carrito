/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiendaabierta;

import java.util.Date;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Naiara
 */
public class CarritoTest {
    
    public CarritoTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getIdCarrito method, of class Carrito.
     */
    @Test
    public void testGetIdCarrito() {
        System.out.println("getIdCarrito");
        Carrito instance = null;
        int expResult = 0;
        int result = instance.getIdCarrito();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setIdCarrito method, of class Carrito.
     */
    @Test
    public void testSetIdCarrito() {
        System.out.println("setIdCarrito");
        int idCarrito = 0;
        Carrito instance = null;
        instance.setIdCarrito(idCarrito);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFechaCreacion method, of class Carrito.
     */
    @Test
    public void testGetFechaCreacion() {
        System.out.println("getFechaCreacion");
        Carrito instance = null;
        Date expResult = null;
        Date result = instance.getFechaCreacion();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setFechaCreacion method, of class Carrito.
     */
    @Test
    public void testSetFechaCreacion() {
        System.out.println("setFechaCreacion");
        Date fechaCreacion = null;
        Carrito instance = null;
        instance.setFechaCreacion(fechaCreacion);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFechaModificacion method, of class Carrito.
     */
    @Test
    public void testGetFechaModificacion() {
        System.out.println("getFechaModificacion");
        Carrito instance = null;
        Date expResult = null;
        Date result = instance.getFechaModificacion();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setFechaModificacion method, of class Carrito.
     */
    @Test
    public void testSetFechaModificacion() {
        System.out.println("setFechaModificacion");
        Date fechaModificacion = null;
        Carrito instance = null;
        instance.setFechaModificacion(fechaModificacion);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Agregar method, of class Carrito.
     */
    @Test
    public void testAgregar() {
        System.out.println("Agregar");
        Producto producto = null;
        int cantidad = 0;
        Carrito.Agregar(producto, cantidad);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ProductoYaFueAgregado method, of class Carrito.
     */
    @Test
    public void testProductoYaFueAgregado() {
        System.out.println("ProductoYaFueAgregado");
        Producto producto = null;
        boolean expResult = false;
        boolean result = Carrito.ProductoYaFueAgregado(producto);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of MostrarCarrito method, of class Carrito.
     */
    @Test
    public void testMostrarCarrito() {
        System.out.println("MostrarCarrito");
        Carrito.MostrarCarrito();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of borrarElementoCarrito method, of class Carrito.
     */
    @Test
    public void testBorrarElementoCarrito() {
        System.out.println("borrarElementoCarrito");
        int idProducto = 0;
        Carrito.borrarElementoCarrito(idProducto);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of MontoDeLaCompra method, of class Carrito.
     */
    @Test
    public void testMontoDeLaCompra() {
        System.out.println("MontoDeLaCompra");
        double expResult = 0.0;
        double result = Carrito.MontoDeLaCompra();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of VaciarCarrito method, of class Carrito.
     */
    @Test
    public void testVaciarCarrito() {
        System.out.println("VaciarCarrito");
        Carrito instance = null;
        instance.VaciarCarrito();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
