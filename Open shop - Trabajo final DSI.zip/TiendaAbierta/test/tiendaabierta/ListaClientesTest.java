/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiendaabierta;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Naiara
 */
public class ListaClientesTest {
    
    public ListaClientesTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of registrarCliente method, of class ListaClientes.
     */
    @Test
    public void testRegistrarCliente() {
        System.out.println("registrarCliente");
        ListaClientes.registrarCliente();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of inicioSeccion method, of class ListaClientes.
     */
    @Test
    public void testInicioSeccion() {
        System.out.println("inicioSeccion");
        ListaClientes.inicioSeccion();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of verificarCuenta method, of class ListaClientes.
     */
    @Test
    public void testVerificarCuenta() {
        System.out.println("verificarCuenta");
        String usuario = "";
        String contrasena = "";
        ListaClientes.verificarCuenta(usuario, contrasena);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
