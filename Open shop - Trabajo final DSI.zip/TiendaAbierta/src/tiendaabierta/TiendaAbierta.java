package tiendaabierta;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import static javax.swing.UIManager.get;
import static tiendaabierta.ListaClientes.clientes;

/**
 *
 * @author Naiara
 */
public class TiendaAbierta {

    private static Object JSON_MAPPER;

    public static void main(String[] args) {

        ArrayList<Producto> productos = new ArrayList<>();
       // ArrayList<ListaClientes> clientes = new ArrayList<>();

        Producto producto1 = new Producto(1, 5, "Celular", "Motorola", "Doble cámara", "Tecnologia", 60000);
        Producto producto2 = new Producto(2, 10, "Heladera", "Briket", "No frost", "Electrodomésticos", 23000);
        Producto producto3 = new Producto(3, 2, "Pava eléctrica", "Liliana", "Automática", "Electrodomésticos", 2500);
        Producto producto4 = new Producto(4, 3, "Notebook", "HP", "Táctil", "Tecnología", 72000);

        productos.add(producto1);
        productos.add(producto2);
        productos.add(producto3);
        productos.add(producto4);

        Cliente cliente1 = new Cliente(11, "Güemes 251 Clucellas", "Santa Fe", 41284026, "tienda02", "naialb12", "naiara@gmail.com", "Naiara", "Albano");
        Cliente cliente2 = new Cliente(12, "Rivadavia 42 San Fco", "Córdoba", 26874125, "flor98", "mflor", "flor14@gmail.com", "Florencia", "Basualdo");

        Scanner entrada = new Scanner(System.in);
        boolean continuar = true;
        int opcion;

        do {
            System.out.println("\nIngrese la opción a realizar: \n"
                    + "\t 1. Mostrar productos\n"
                    + "\t 2. Agregar productos al carrito\n"
                    + "\t 3. Registrar cliente\n"
                    + "\t 4. Iniciar sección\n"
                    + "\t 5. Generar compra\n"
                    + "\t --> Seleccione otro número para finalizar.");

            opcion = entrada.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("LISTA DE PRODUCTOS\n");
                    System.out.println("====================================\n");
                    productos.forEach((prod) -> {
                        System.out.print(prod.getNombre() + " " + prod.getMarca() + " " + "$" + prod.getPrecio() + "\n-----------------------------\n");
                    });

                    break;

                case 2:
                    int cantidad;

                    System.out.println("¿Que producto desea agregar al carrito?");
                    int pos = 0;

                    productos.forEach((prod) -> {
                        System.out.print("\n " + prod.getIdProducto() + ". " + prod.getNombre() + " " + prod.getMarca() + "\n");

                    });
                    Producto.MostrarProductos();
                    System.out.println("\nProducto: ");
                    pos = entrada.nextInt();
                    int elegido = pos - 1;

                    Producto producto = productos.get(elegido);

                    System.out.println("\n¿Cuántas unidades?");
                    cantidad = entrada.nextInt();

                    boolean productoDisponible = Producto.verificarStock(producto, cantidad);
                    if (productoDisponible == true) {
                        Carrito.Agregar(producto, cantidad);
                    } else {
                        System.out.println("No hay producto en stock.");
                    }

                    Carrito.Agregar(producto, cantidad);
                    Carrito.MostrarCarrito();

                    System.out.println("\n¿Desea quitar un elemento del carrito?");
                    String respuesta = entrada.nextLine();

                    if ("si".equals(respuesta)) {

                        Carrito.borrarElementoCarrito(elegido);

                    }

                    break;

                case 3:

                    System.out.println("\nREGISTRAR UN NUEVO CLIENTE");
                    System.out.println("====================================\n");

                    ListaClientes.registrarCliente();

                    break;

                case 4:
                    System.out.println("\nINICIO DE SECCIÓN");
                    System.out.println("====================================\n");
                    ListaClientes.inicioSeccion();
                    break;

                case 5:
                    System.out.println("\nGENERAR COMPRA");
                    System.out.println("====================================\n");

                    Carrito.MostrarCarrito();
                    System.out.println("Si desea generar la compra presione 1\n");
                    int presion = entrada.nextInt();

                    if (presion == 1) {
                        double monto = Carrito.MontoDeLaCompra();
                        System.out.println("El monto de la compra es: " + monto);
                    }

                default:
                    System.out.println("¡Gracias por su visita!");
                    continuar = false;
                    break;
            }
        } while (continuar);

        JSON_MAPPER.whiteValue(new File("C:/Users/Naiara/Documents/NetBeansProjects/TiendaAbierta.json"), clientes);

        
        productos = JSON_MAPPER.readValue(new File("C:/Users/Naiara/Documents/NetBeansProjects/TiendaAbierta.json"),
                JSON_MAPPER.getTypeFactory().constructCollection(ArrayList.class, Producto.class)); 
        
    }
}
