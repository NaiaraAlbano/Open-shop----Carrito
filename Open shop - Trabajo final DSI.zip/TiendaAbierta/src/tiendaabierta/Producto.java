package tiendaabierta;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Naiara
 */
public class Producto {

    int idProducto;
    int stock;
    String nombre;
    String marca;
    String descripcion;
    String categoria;
    float precio;

    static ArrayList<Producto> productos;

    public Producto(int idProducto, int cantStock, String nombre, String marca, String descripcion, String categoria, float precio) {
        this.productos = new ArrayList<>();
        this.idProducto = idProducto;
        this.stock = cantStock;
        this.nombre = nombre;
        this.marca = marca;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.precio = precio;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getStock() {
        return stock;
    }

    public void setCantStock(int stock) {
        this.stock = stock;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public static boolean verificarStock(Producto producto, int cantidad) {
        boolean productoDisponible = false;
        int cantDisponible = producto.getStock();

        System.out.println("Cant disp. : " + cantDisponible);

        if (cantDisponible <= cantidad) {
            productoDisponible = true;
        }
        return productoDisponible;
    }

    public static void MostrarProductos() {
        productos.forEach((prod) -> {
            System.out.print("\n " + prod.getIdProducto() + prod.getNombre());
        });
    }

    public boolean HayStockDisponible() {
        boolean resultado = false;
        if (stock > 0) {
            resultado = true;
        }

        return resultado;
    }

    public boolean HaySuficienteStock(int cantidadDeUnidadesAComprar) {
        boolean resultado = false;
        if (cantidadDeUnidadesAComprar <= stock) {
            resultado = true;
        }

        return resultado;
    }
    
    public void cargarProductos() {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingresar IdProducto");
        idProducto = entrada.nextInt();
        System.out.println("Ingresar nombre del producto");
        nombre = entrada.nextLine();
        System.out.println("Ingresar marca del producto");
        marca = entrada.nextLine();
        System.out.println("Ingresar descripción del producto");
        descripcion = entrada.nextLine();
        System.out.println("Ingresar categoría del producto");
        categoria = entrada.nextLine();
        stock = entrada.nextInt();
        precio = entrada.nextFloat();

        Producto nuevoProducto = new Producto(idProducto, stock, nombre, marca, descripcion, categoria, precio);
        productos.add(nuevoProducto);
    }

}
