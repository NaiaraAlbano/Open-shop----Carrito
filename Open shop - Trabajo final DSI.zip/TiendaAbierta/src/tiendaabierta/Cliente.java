package tiendaabierta;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Naiara
 */
public class Cliente {

    int idCliente;
    String domicilio;
    String provincia;
    int dni;
    String contrasena;
    String usuario;
    String mail;
    String nombre;
    String apellido;

    public Cliente(int idCliente, String domicilio, String provincia, int dni, String contrasena, String usuario, String mail, String nombre, String apellido) {
        this.idCliente = idCliente;
        this.domicilio = domicilio;
        this.provincia = provincia;
        this.dni = dni;
        this.contrasena = contrasena;
        this.usuario = usuario;
        this.mail = mail;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    
    

}
