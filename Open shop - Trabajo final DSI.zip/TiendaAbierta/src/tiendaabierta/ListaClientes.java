package tiendaabierta;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Naiara
 */
public class ListaClientes {

    static Scanner entrada = new Scanner(System.in);
    static ArrayList<Cliente> clientes = new ArrayList();
    private static Object JSON_MAPPER;

    public static void registrarCliente() {

        boolean registrar = true;
        do {
            System.out.println("Ingrese el nombre: \n");
            String nombre = entrada.nextLine();
            System.out.println("Ingrese el IdCLiente: \n");
            int idCliente = entrada.nextInt();
            System.out.println("Ingrese el apellido: \n");
            String apellido = entrada.nextLine();
            System.out.println("Ingrese el dni: \n");
            int dni = entrada.nextInt();
            System.out.println("Ingrese el mail: \n");
            String mail = entrada.nextLine();
            System.out.println("Ingrese el domicilio: \n");
            String domicilio = entrada.nextLine();
            System.out.println("Ingrese el provincia: \n");
            String provincia = entrada.nextLine();
            System.out.println("Ingrese el nombre de usuario: \n");
            String usuario = entrada.nextLine();
            System.out.println("Ingrese el contraseña: \n");
            String contrasena = entrada.nextLine();

            Cliente nuevoCliente = new Cliente(idCliente, domicilio, provincia, dni, usuario, contrasena, mail, nombre, apellido);
            clientes.add(nuevoCliente);

            int continuar = 0;
            System.out.println("¿Desea registrar un nuevo cliente? Presione 1 sino precione 0");
            continuar = entrada.nextInt();
            if (continuar == 0) {
                registrar = false;
            }

        } while (registrar);
        
        
    }

    public static void inicioSeccion() {

        System.out.println("Ingrese el nombre de usuario: \n");
        String usuario = entrada.nextLine();
        System.out.println("Ingrese el contraseña: \n");
        String contrasena = entrada.nextLine();

        verificarCuenta(usuario, contrasena);
    }

    public static void verificarCuenta(String usuario, String contrasena) {
      

        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).usuario.equals(usuario)) {
                System.out.println("Usuario válido");

                if (clientes.get(i).contrasena.equals(contrasena)) {
                    System.out.println("Contraseña válida");
                    System.out.println("Sección iniciada correctamente");
                } else {
                    System.out.println("Contraseña inválida");
                }
            } else {
                System.out.println("Usuario inválido");
            }
        }

    }
    
    
}
