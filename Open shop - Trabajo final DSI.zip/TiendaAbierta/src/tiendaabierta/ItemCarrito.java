package tiendaabierta;

import java.io.File;
import java.util.ArrayList;
import static tiendaabierta.ListaClientes.clientes;

/**
 *
 * @author Naiara
 */
public class ItemCarrito {

    public Producto Producto;
    public int Cantidad;

    public ItemCarrito() {
    }

    public void AumentarCantidad(int cantidadAgregada) {
        Cantidad = Cantidad + cantidadAgregada;
    }

    public void ModificarCantidad(int nuevaCantidad) {
        Cantidad = nuevaCantidad;
    }
}
